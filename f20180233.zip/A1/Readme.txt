Before starting ensure that you have mysql on your machine.

Create a database named user_chats
Create two tables namely chats & user
Change the username and the password in the python files app & conversation

Backend Server can be run by typing python app.py

The Tikri folder contains the frontend code files.

The front end Android part can be run in Android Studio.

Set up Android Studio,and install an emulator for testing/running the app.
Open the Tikri folder in Android Studio.
Press the Play button to run the app.
This code was run on Pixel 4XL API level 30 device at the time of development.